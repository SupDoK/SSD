/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ssdprojectv1;

/**
 *
 * @author Benjamin
 */
public class User {
    private char[] name_;
    private char[] firstname_;
    private char[] mail_;
    private char[] password_;
    
    public User(char[] name, char[] firstname, char[] mail, char[] password){
        this.name_ = name;
        this.firstname_ = firstname;
        this.mail_ = mail;
        this.password_ = password;
        
    }
    
    public char[] getName(){
        return this.name_;
    }
    
    public char[] getFirstname(){
        return this.firstname_;
    }
    
    public char[] getMail(){
        return this.mail_;
    }
    
    public char[] getPass(){
        return this.password_;
    }
}
