package ssdprojectv1;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;
import java.security.SecureRandom;
 
//CLASS imports
import ssdprojectv1.User;
 
///MAIL imports
 
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Loic & Benjamin
 */
 
 //Checker la connexion internet pour envoyer le mail de vérif
 
public class SSDProjectV1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        //CONVERTIR TOUS LES STRING EN CHAR
        Scanner sc = new Scanner(System.in);
        String mail;
        String password;
        
        
        char ans;//Char sinon exception avec un int quand on rentre un char
        int ansMail;
        int tempSecret = -1;
        int upThread = 10000;
        
        int temp = 0;
        int i = 1;
        int j = 0;
        int k = 0;
        
        do{//Menu 1
            System.out.println("What grade are you ?");
            System.out.println("1. Student");
            System.out.println("2. Teacher");
            System.out.println("3. Admin");

            ans = sc.next().charAt(0);
            switch(ans){
                case '1':
                    System.out.println("Hey student, please enter your credentials");
                    System.out.println("Mail :");
                    mail = sc.next();
                    System.out.println("Password : ");
                    password = sc.next();
                    
                    
                    if(mail.equals("ben") && password.equals("benji")){
                        System.out.println("Your credentials are correct");
                        System.out.println("We send you a mail to email you gave us");
                        TestConnection();//Test pour verif connexion internet !!!    
                        //tempSecret = SendMail(mail);//Envoi du mail
                        do{
                            System.out.println("Enter secret code sends to email");
                            ansMail = sc.nextInt();
                            sc.reset();
                            if(tempSecret == ansMail && tempSecret != -1 && k < 5){
                                j = 1;
                                System.out.println("Hey _addnameofuserfromDB_ ");
                                System.out.println("");
                                System.out.println("Which course would you show you ?");

                                //Récupérer l'élève ciblé de la base de donnée
                                //PUIS
                                //Afficher l'ensemble de ses cours avec ses points correspondants
                            }
                            else if(k == 4){//Si le code est mauvais + de 5 fois, augmenter le temps d'attente
                                System.out.println("Please wait...");
                                try {
                                    //boucle de 10 sec dans le thread principal puis exponentiel en fonction de cas, on ralonge le temps d'att
                                    Thread.sleep(upThread);
                                    upThread *= 2;//time is exponentiel 
                                } catch (InterruptedException ex) {
                                    Logger.getLogger(SSDProjectV1.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                            else{
                                k++;
                            }
                        }while(j == 0);
                    }
                    else{
                        System.out.println("Bad password or email");
                    }
                    temp = 1;
                    break;
                case '2':
                    
                    
                    System.out.println("Hey teacher, please enter your credentials");
                    System.out.println("Mail :");
                    mail = sc.next();
                    System.out.println("Password : ");
                    password = sc.next();
                    
                    if(mail.equals("ben") && password.equals("benji")){
                        System.out.println("Your credentials are correct");
                        System.out.println("We send you a mail to email you gave us");
                        TestConnection();//Test pour verif connexion internet !!!  
                       
                        do{
                            System.out.println("Enter secret code sends to email");
                            ansMail = sc.nextInt();
                            sc.reset();
                            if(tempSecret == ansMail && tempSecret != -1 && k < 5){
                                j = 1;
                                System.out.println("Hey _addnameofuserfromDB_ ");//Afficher le nom de l'utilisateur
                                System.out.println("");
                                System.out.println("What's student name that you want to modify");

                                //Récupérer la liste des élèves pour le cours donné par le prof et l'afficher

                                //Récupérer l'élève ciblé de la base de donnée
                                //PUIS
                                //Afficher le cours du prof avec ses points correspondants de l'élève
                                //Modifier dans la base de donnée et réafficher les cours changés dans la console
                            }
                            else if(k == 4){//Si le code est mauvais + de 5 fois, augmenter le temps d'attente
                                System.out.println("Please wait...");
                                try {
                                    //boucle de 10 sec dans le thread principal puis exponentiel en fonction de cas, on ralonge le temps d'att
                                    Thread.sleep(upThread);
                                    upThread *= 2;//time is exponentiel 
                                } catch (InterruptedException ex) {
                                    Logger.getLogger(SSDProjectV1.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                            else{
                                k++;
                            }
                        }while(j == 0);
                        
                    }
                    else{
                        System.out.println("Bad password or email");
                    }
                    temp = 1;
                    break;
                case '3':
                    //int k = 0;
                    System.out.println("Hey my super admin, please enter your credentials");
                    System.out.println("Mail :");
                    mail = sc.next();
                    sc.reset();
                    System.out.println("Password : ");
                    password = sc.next();
                    sc.reset();
                    //ENVOIE DEMANDE AU SERVEUR POUR
                    //Recup le mdp et l'adresse mail (en recherchant celle que la personne à donnée) dans la db et tester les credentials
                    
                    if(mail.equals("bencochez86@gmail.com") && password.equals("benji")){
                        System.out.println("Your credentials are correct");
                        System.out.println("We send you a mail to email you gave us");
                        TestConnection();//Test pour verif connexion internet !!!    
                        //Envoie de la requête au serveur pour générer un mail
                        Socket socket = new Socket("127.0.0.1", 9000);

                        try(ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                            ObjectInputStream in = new ObjectInputStream(socket.getInputStream())){
                            out.writeObject("ok");
                            String rep = (String)in.readObject();
                            if("ok".equals(rep)){
                                System.out.println("Mail has been sent");
                                tempSecret = in.readInt();
                            }

                            out.close();
                            in.close();
                            socket.close();//Fermeture socket
                        }catch(Exception e){
                            e.printStackTrace();
                        }

                        do{
                            System.out.println("Enter secret code sends to email");
                            ansMail = sc.nextInt();
                            sc.reset();
                            if(tempSecret == ansMail && tempSecret != -1 && k < 5){
                                j = 1;
                                System.out.println("Hey _addnameofuserfromDB_ ");//Afficher le nom de l'utilisateur
                                System.out.println("");
                                
                                //Récupérer la liste des élèves et l'afficher
                                //Récupérer l'élève ciblé de la base de donnée
                                //PUIS
                                //Afficher l'ensemble de ses cours avec ses points correspondants
                                //Demander quel cours il souhaite modifier
                                //Modifier dans la base de donnée et réafficher les cours changés dans la console
                            }
                            else if(k == 4){//Si le code est mauvais + de 5 fois, augmenter le temps d'attente
                                System.out.println("Please wait...");
                                try {
                                    //boucle de 10 sec dans le thread principal puis exponentiel en fonction de cas, on ralonge le temps d'att
                                    Thread.sleep(upThread);
                                    upThread *= 2;//time is exponentiel 
                                } catch (InterruptedException ex) {
                                    Logger.getLogger(SSDProjectV1.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                            else{
                                k++;
                            }
                        }while(j == 0);
                    }
                    else{
                        System.out.println("Bad password or email");
                    }
                    temp = 1;
                    break;
                default:
                    System.out.println("ERROR ! Please select a number between 1 and 3");
                    break;
            }
        }while(temp == 0);
    }
    
    public static void TestConnection(){//Test connection for know if client has internet
        final URL url;
        Scanner scBis = new Scanner(System.in);
        int ansConnect;
        int temp = 0;
        try {
            url = new URL("http://www.google.com"); 
            final URLConnection conn = url.openConnection();
            conn.connect();
            temp = 1;
        } catch (MalformedURLException ex) {
            Logger.getLogger(SSDProjectV1.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Pliz check your internet connection, enter 1 to continue, or 2 to exit program");
            ansConnect = scBis.nextInt();
            switch(ansConnect){
                case 1:
                    System.out.println("You continue...");
                    break;
                case 2 : 
                    System.exit(0);
                    break;
                default:
                    System.out.println("Enter a valid number pliz");
                    break;
            }
        } catch (IOException ex) {
            Logger.getLogger(SSDProjectV1.class.getName()).log(Level.SEVERE, null, ex);
            ansConnect = scBis.nextInt();
            switch(ansConnect){
                case 1:
                    System.out.println("You continue...");
                    break;
                case 2 : 
                    System.exit(0);
                    break;
                default:
                    System.out.println("Enter a valid number pliz");
                    break;
            }
        }
    }
}
