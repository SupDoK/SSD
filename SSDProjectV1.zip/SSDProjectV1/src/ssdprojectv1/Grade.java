/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ssdprojectv1;

/**
 *
 * @author Benjamin
 */
public class Grade {
    private char[] label_;
    private float note_;
    
    public Grade (char[] label, float note){
        this.label_ = label;
        this.note_ = note;
    }
    
    
}
