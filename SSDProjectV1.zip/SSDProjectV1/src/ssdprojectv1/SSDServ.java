package ssdprojectv1;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.SecureRandom;

//NETWORK IMPORT
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

//MAIL IMPORT
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Benjamin et Loic
 */
public class SSDServ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        SSDServ serveur = new SSDServ();
        serveur.demarrer();
    }
    
    private void demarrer() throws IOException {     
        ServerSocket ss = new ServerSocket(9000);
        
        while(true){
            Socket s = ss.accept();
            System.out.println("Un client s'est connecté");
            // ...
            Thread communication = new Thread(() -> {
                try (ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
                        ObjectInputStream in = new ObjectInputStream(s.getInputStream())) {
                    int nbGenerated;
                    String repOk = (String)in.readObject();   
                    if("ok".equals(repOk)){
                        nbGenerated = SendMail("bencochez86@gmail.com");
                        System.out.println(nbGenerated);
                        out.writeObject("ok");
                        out.writeInt(nbGenerated);
                    }
                    else{
                        //log => mauvaise requête sur le serveur
                    }

                    
                    
                    //in.close();
                    out.close();
                    s.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            communication.setDaemon(true);
            communication.start();
        } 
    }
    
    public static void TestConnection(){//Test connection for know if client has internet
        final URL url;
        Scanner scBis = new Scanner(System.in);
        int ansConnect;
        int temp = 0;
        try {
            url = new URL("http://www.google.com"); 
            final URLConnection conn = url.openConnection();
            conn.connect();
            temp = 1;
        } catch (MalformedURLException ex) {
            Logger.getLogger(SSDProjectV1.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Pliz check your internet connection, enter 1 to continue, or 2 to exit program");
            ansConnect = scBis.nextInt();
            switch(ansConnect){
                case 1:
                    System.out.println("You continue...");
                    break;
                case 2 : 
                    System.exit(0);
                    break;
                default:
                    System.out.println("Enter a valid number pliz");
                    break;
            }
        } catch (IOException ex) {
            Logger.getLogger(SSDProjectV1.class.getName()).log(Level.SEVERE, null, ex);
            ansConnect = scBis.nextInt();
            switch(ansConnect){
                case 1:
                    System.out.println("You continue...");
                    break;
                case 2 : 
                    System.exit(0);
                    break;
                default:
                    System.out.println("Enter a valid number pliz");
                    break;
            }
        }
    }
    
    public static int SendMail(String mail){
        final String username = "alphatangototo789@gmail.com";
        final String password = "HI2LlOvoTCe2VcZtRqQD";
        
        SecureRandom rand = new SecureRandom(); //CREATE SECRET MDP TO SEND TO MAIL
        int tempSecret = rand.nextInt(100000);//Generation d'un entier entre 0 et 99999

        Properties prop = new Properties();
	prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS
        
        Session session = Session.getInstance(prop,
            new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {//Sender account
                    return new PasswordAuthentication(username, password);
                }
            });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("alphatangototo789@gmail.com"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    //InternetAddress.parse("bencochez86@gmail.com, alphatangototo789@gmail.com")//Destination mails (with a copy to sender)
                    InternetAddress.parse(mail + ", alphatangototo789@gmail.com")
            );
            message.setSubject("Verification of SUPER SSD application");
            message.setText("Your code is," + "\n\n " + tempSecret);

            Transport.send(message);

            System.out.println("Code is send");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
        return tempSecret;
    }
}
